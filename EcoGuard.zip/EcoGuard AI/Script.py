import tkinter as tk
from tkinter import filedialog, messagebox
from ttkthemes import ThemedTk
from PIL import Image, ImageTk, ImageDraw
import torch
from transformers import CLIPProcessor, CLIPModel, DetrImageProcessor, DetrForObjectDetection
import cv2
import threading

# UI Colors
DARK_BG = "#121212"
ACCENT_COLOR = "#4CAF50"
BUTTON_BG = "#333333"
BUTTON_FG = "#ffffff"
LABEL_FG = "#ffffff"

# Global Variables
always_on_top = False

# Function for Object Detection
def detect_objects(pil_image):
    inputs = detr_processor(images=pil_image, return_tensors="pt")
    outputs = detr_model(**inputs)
    target_sizes = torch.tensor([pil_image.size[::-1]])
    results = detr_processor.post_process_object_detection(outputs, target_sizes=target_sizes, threshold=0.8)[0]

    objects = []
    for score, label, box in zip(results["scores"], results["labels"], results["boxes"]):
        objects.append({"label": detr_model.config.id2label[label.item()], "box": box.tolist()})
    return objects

# Function for Material Classification
def classify_material(pil_image):
    texts = ["plastic", "glass", "metal", "paper", "organic material"]
    inputs = clip_processor(text=texts, images=pil_image, return_tensors="pt", padding=True)
    outputs = clip_model(**inputs)
    logits = outputs.logits_per_image
    probs = logits.softmax(dim=1)
    best_match = texts[torch.argmax(probs)]
    return best_match

# Function for Image Analysis
def classify_waste_clip_from_pil(pil_image):
    objects = detect_objects(pil_image)
    if not objects:
        return "No recognizable waste detected."

    main_object = max(objects, key=lambda obj: (obj["box"][2] - obj["box"][0]) * (obj["box"][3] - obj["box"][1]))

    x_min, y_min, x_max, y_max = map(int, main_object["box"])
    cropped_image = pil_image.crop((x_min, y_min, x_max, y_max))

    material = classify_material(cropped_image)
    recyclable_materials = {"plastic", "glass", "metal", "paper"}
    classification = "Recyclable" if material in recyclable_materials else "Non-Recyclable"

    draw = ImageDraw.Draw(pil_image)
    draw.rectangle([x_min, y_min, x_max, y_max], outline=ACCENT_COLOR, width=4)

    return f"{classification} - Material: {material}"

# Function to Capture a Photo
def real_time_pic():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        messagebox.showerror("Error", "Could not open webcam.")
        return

    ret, frame = cap.read()
    if not ret:
        messagebox.showerror("Error", "Failed to capture image.")
        cap.release()
        return

    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    frame_pil = Image.fromarray(frame_rgb)

    result = classify_waste_clip_from_pil(frame_pil)
    result_label.config(text=result)

    display_image = frame_pil.copy()
    display_image.thumbnail((300, 300))
    img_tk = ImageTk.PhotoImage(display_image)
    image_label.config(image=img_tk)
    image_label.image = img_tk

    cap.release()

# Function to Upload a Photo
def upload_pic():
    file_path = filedialog.askopenfilename(title="Select Image", filetypes=[("Image Files", "*.png;*.jpg;*.jpeg")])
    if not file_path:
        return
    try:
        pil_image = Image.open(file_path).convert("RGB")
    except Exception as e:
        messagebox.showerror("Error", f"Failed to load image: {e}")
        return

    result = classify_waste_clip_from_pil(pil_image)
    result_label.config(text=result)

    display_image = pil_image.copy()
    display_image.thumbnail((300, 300))
    img_tk = ImageTk.PhotoImage(display_image)
    image_label.config(image=img_tk)
    image_label.image = img_tk

# Toggle Always-On-Top
def toggle_always_on_top():
    global always_on_top
    always_on_top = not always_on_top
    root.attributes("-topmost", always_on_top)

# Page Switching Functions
def show_home():
    home_frame.pack(pady=30)
    functions_frame.pack_forget()
    settings_frame.pack_forget()

def show_functions():
    home_frame.pack_forget()
    functions_frame.pack(pady=30)
    settings_frame.pack_forget()

def show_settings():
    home_frame.pack_forget()
    functions_frame.pack_forget()
    settings_frame.pack(pady=30)

# Load AI Models
def load_models():
    global clip_model, clip_processor, detr_processor, detr_model
    clip_model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32")
    clip_processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")
    detr_processor = DetrImageProcessor.from_pretrained("facebook/detr-resnet-50")
    detr_model = DetrForObjectDetection.from_pretrained("facebook/detr-resnet-50")

# Start Model Loading in a Thread
def start_loading_thread():
    threading.Thread(target=load_models, daemon=True).start()

# UI Setup
root = ThemedTk(theme="sun-valley")
root.title("EcoGuard AI")
root.geometry("1920x1080")
root.configure(bg=DARK_BG)

# Header Buttons
header_frame = tk.Frame(root, bg=DARK_BG)
header_frame.pack(pady=10)

tk.Button(header_frame, text="Home", command=show_home, font=("Helvetica", 18), fg=BUTTON_FG,
          bg=BUTTON_BG, relief="flat", padx=20, pady=10).grid(row=0, column=0, padx=20)

tk.Button(header_frame, text="Main Functions", command=show_functions, font=("Helvetica", 18), fg=BUTTON_FG,
          bg=BUTTON_BG, relief="flat", padx=20, pady=10).grid(row=0, column=1, padx=20)

tk.Button(header_frame, text="Settings", command=show_settings, font=("Helvetica", 18), fg=BUTTON_FG,
          bg=BUTTON_BG, relief="flat", padx=20, pady=10).grid(row=0, column=2, padx=20)

# Home Frame
home_frame = tk.Frame(root, bg=DARK_BG)
tk.Label(home_frame, text="Welcome to EcoGuard AI!", font=("Helvetica", 18), fg=LABEL_FG, bg=DARK_BG).pack(pady=20)
tk.Label(home_frame, text="Your enviromental guardian when it comes to recycling!", font=("Helvetica", 18), fg=LABEL_FG, bg=DARK_BG).pack(pady=20)

# Main Functions Frame
functions_frame = tk.Frame(root, bg=DARK_BG)

instr_label = tk.Label(functions_frame, text="Take or Upload a Picture:", font=("Helvetica", 18), fg=LABEL_FG, bg=DARK_BG)
instr_label.pack(pady=10)

button_frame = tk.Frame(functions_frame, bg=DARK_BG)
button_frame.pack(pady=20)

tk.Button(button_frame, text="Take Photo", command=real_time_pic, font=("Helvetica", 18), fg=BUTTON_FG,
          bg=BUTTON_BG, relief="flat", padx=20, pady=10).pack(pady=10)

tk.Button(button_frame, text="Upload Photo", command=upload_pic, font=("Helvetica", 18), fg=BUTTON_FG,
          bg=BUTTON_BG, relief="flat", padx=20, pady=10).pack(pady=10)

result_label = tk.Label(functions_frame, text="Results...", font=("Helvetica", 18), fg=LABEL_FG, bg=DARK_BG)
result_label.pack(pady=20)

image_label = tk.Label(functions_frame, bg=DARK_BG)
image_label.pack(pady=30)

# Settings Frame
settings_frame = tk.Frame(root, bg=DARK_BG)
tk.Label(settings_frame, text="Settings", font=("Helvetica", 18), fg=LABEL_FG, bg=DARK_BG).pack(pady=20)

# Start on Home
show_home()
start_loading_thread()

root.mainloop()
